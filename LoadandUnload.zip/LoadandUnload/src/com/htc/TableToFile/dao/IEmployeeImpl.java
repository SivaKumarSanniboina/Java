package com.htc.TableToFile.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.htc.TableToFile.dbconnection.DbConnector;
import com.htc.TableToFile.entity.EmployeeList;


public class IEmployeeImpl 
{
	public static Logger logger =Logger.getLogger(IEmployeeImpl.class);
	public void readFileFromFile() throws IOException, SQLException 
	{
          
		File file = new File("src\\EmployeeListDetails.xlsx");


		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0); 
		Iterator<Row> itr = sheet.iterator();

		Row row = itr.next();
		int insert_table_counter = 0;
		int read_file_counter = 0;
		while (itr.hasNext()) 
		{
			row = itr.next();
			Iterator<Cell> cellIterator = row.cellIterator(); 

			
			while (cellIterator.hasNext())
			{
				
				Cell cell = cellIterator.next();
				int empId = (int)cell.getNumericCellValue();

				cell = cellIterator.next();
				String empName = cell.getStringCellValue();

				cell = cellIterator.next();
				double salary = cell.getNumericCellValue();
				
				cell = cellIterator.next();
				String emailid = cell.getStringCellValue();

				cell = cellIterator.next();
				String gender = cell.getStringCellValue();
				 if(gender.equals("male"))
				 {
					 EmployeeList obj = new EmployeeList(empId,empName,salary,emailid,gender);
					 insertToTable(obj);
				 }
           	  logger.info("inserted to table");
             
		    } 
		}
	}
	private boolean insertToTable(EmployeeList obj) throws SQLException, IOException{

		boolean status = false;

		Connection con = DbConnector.getConnection();
				
		PreparedStatement ps = con.prepareStatement(
				"INSERT INTO employeedetails(empId, empName, salary, emailid, gender) VALUES(?,?,?,?,?)");

		ps.setInt(1, obj.getEmpId());
		ps.setString(2, obj.getEmpName());
		ps.setDouble(3, obj.getSalary());
		ps.setString(4, obj.getEmailid());
		ps.setString(5, obj.getGender());
		status = !ps.execute(); 

		return status;
	
}
	public static Logger logger1 =Logger.getLogger(IEmployeeImpl.class);
	public void readFileFromFile1() throws IOException, SQLException {
		
	        ArrayList<EmployeeList> genders =new ArrayList<>();
		File file = new File("src\\EmployeeListDetails.xlsx");


		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0); 
		Iterator<Row> itr = sheet.iterator();

		Row row = itr.next();
		int insert_table_counter = 0;
		int read_file_counter = 0;
		while (itr.hasNext()) 
		{
			row = itr.next();
			Iterator<Cell> cellIterator = row.cellIterator(); 

			
			while (cellIterator.hasNext()) {
				
				Cell cell = cellIterator.next();
				int empId = (int)cell.getNumericCellValue();

				cell = cellIterator.next();
				String empName = cell.getStringCellValue();

				cell = cellIterator.next();
				double salary = cell.getNumericCellValue();
				
				cell = cellIterator.next();
				String emailid = cell.getStringCellValue();

				cell = cellIterator.next();
				String gender = cell.getStringCellValue();
				 if(gender.equals("female")) {
	            	  EmployeeList obj = new EmployeeList(empId,empName,salary,emailid,gender);
	            	  genders.add(obj);
	            	  System.out.println(genders);
	            	  writeFile1(genders);
	              }
	            
	            	  
			}
		}
	}

	private void writeFile1(ArrayList<EmployeeList> genders) throws IOException {
		// TODO Auto-generated method stub
		XSSFWorkbook wb = new XSSFWorkbook();

		XSSFSheet spreedsheet = wb.createSheet("genderDetails");
		FileOutputStream fos = new FileOutputStream("genderDetails.xlsx");
		XSSFRow row;
		int rowno = 0;
		int cellno = 0;

		row = spreedsheet.createRow(rowno);
		Cell cell = row.createCell(cellno);

		cell = row.createCell(cellno);
		cell.setCellValue("empId");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("empName");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("salary");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("emailid");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("gender");
		cellno++;
		rowno++;

		for (EmployeeList cc : genders) {
			row = spreedsheet.createRow(rowno);

			cellno = 0;
			cell = row.createCell(cellno);
			cell.setCellValue(cc.getEmpId());
			cellno++;

			cell = row.createCell(cellno);
			cell.setCellValue(cc.getEmpName());
			cellno++;

			cell = row.createCell(cellno);
			cell.setCellValue(cc.getSalary());
			cellno++;

			cell = row.createCell(cellno);
			cell.setCellValue(cc.getEmailid());
			cellno++;
			cell = row.createCell(cellno);
			cell.setCellValue(cc.getGender());
			cellno++;
			rowno++;
		}

		wb.write(fos);

		fos.close();
		System.out.println("Excel File Created!!");
		logger1.info("inserted to table");

		
		
	}

}

