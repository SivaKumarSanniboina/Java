package com.strings.exercise8;

public class InitialCapitalization4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String name="siva kumar";
		 
		 String firstLetter=name.substring(0,1);
		 String remainingLetters=name.substring(1,name.length());

		 firstLetter=firstLetter.toUpperCase();

		 name=firstLetter+remainingLetters;
		 System.out.println("Name: " + name);

	}

}
