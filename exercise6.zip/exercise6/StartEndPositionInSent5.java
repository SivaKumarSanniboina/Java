package com.strings.exercise8;

public class StartEndPositionInSent5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="Siva is Funny";
		
		char char_at = str.charAt(0);
		System.out.println("Character at first position is: "+char_at);
		
		char char_at1 = str.charAt(str.length()-1);
		System.out.println("Character at last position is : "+char_at1);
		

	}

}
