package com.strings.exercise8;

public class CheckOutTheCode1
{
    public static void main(String[] arg) {
	   int a = 10;
	   int b = 100;
     
 System.out.println(" The added value is " + a + b);
 
 System.out.println(a+b+" is the added value ");

 System.out.println(a-b+" is the Subtracted value is ");

 System.out.println("The Subtracted value is " + (a-b));

 System.out.println("The Multiplied value is "+ a*b);
	
 System.out.println("The Divided value is "+ a /b);
  
   }

    
     }


