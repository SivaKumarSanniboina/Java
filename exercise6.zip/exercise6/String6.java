package com.strings.exercise8;

public class String6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	      String s1="I have to win, Keep this in heart.How I have to Win ,Keep this in brain.Then you will win";
	      
	      String firstLetter = s1.substring(0, 8);
	      String remainingLetters = s1	.substring(8, s1.length());
	      
	      remainingLetters = remainingLetters.toUpperCase();
	      
	      s1 = firstLetter + remainingLetters;
	      
	      System.out.println(s1);

	}

}
