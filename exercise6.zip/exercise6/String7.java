package com.strings.exercise8;

public class String7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hai|you|are|how";
		
		String firstWord=str.substring(0,3);
		String secondWord=str.substring(4,7);
		String thirdWord=str.substring(8,11);
		String fourthWord=str.substring(12,15);
		
		str = firstWord + secondWord + thirdWord + fourthWord;
		
		System.out.println(str);

	}

}
