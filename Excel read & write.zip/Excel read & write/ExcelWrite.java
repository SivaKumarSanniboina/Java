import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


	import org.apache.poi.hssf.usermodel.HSSFWorkbook;
	import org.apache.poi.ss.usermodel.Cell;
	import org.apache.poi.ss.usermodel.CellType;
	import org.apache.poi.ss.usermodel.Row;
	import org.apache.poi.ss.usermodel.Sheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelWrite {

		public static void main(String[] args) {
			
			try {
				FileOutputStream fos = new FileOutputStream("product.xlsx");
				HSSFWorkbook xlsx = new HSSFWorkbook();
				Sheet sheet = xlsx.createSheet("Product");
				Row row = sheet.createRow(0);
				Cell cell = row.createCell(0);
				cell.setCellValue("ProductID");
				cell = row.createCell(1);
				cell.setCellValue("ProductName");
				cell = row.createCell(2);
				cell.setCellValue("Quantity");
				cell = row.createCell(3);
				cell.setCellValue("UnitPrice");
				
				Row row1 = sheet.createRow(1);
				row1.createCell(0,CellType.STRING).setCellValue("P001");
				row1.createCell(1,CellType.STRING).setCellValue("Pen");
				row1.createCell(2,CellType.NUMERIC).setCellValue("63");
				row1.createCell(3,CellType.NUMERIC).setCellValue("50");
				
				Row row2 = sheet.createRow(2);
				row2.createCell(0,CellType.STRING).setCellValue("P002");
				row2.createCell(1,CellType.STRING).setCellValue("Pencil");
				row2.createCell(2,CellType.NUMERIC).setCellValue("63");
				row2.createCell(3,CellType.NUMERIC).setCellValue("50");
				
				Row row3 = sheet.createRow(3);
				row3.createCell(0,CellType.STRING).setCellValue("P003");
				row3.createCell(1,CellType.STRING).setCellValue("Pendrive");
				row3.createCell(2,CellType.NUMERIC).setCellValue("63");
				row3.createCell(3,CellType.NUMERIC).setCellValue("500");
				
				Row row4 = sheet.createRow(4);
				row4.createCell(0,CellType.STRING).setCellValue("P004");
				row4.createCell(1,CellType.STRING).setCellValue("Mouse");
				row4.createCell(2,CellType.NUMERIC).setCellValue("63");
				row4.createCell(3,CellType.NUMERIC).setCellValue("50");
				
				xlsx.write(fos);
				fos.close();
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}