package com.htc.composition1;

public class Main {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Human bob = new Human( "bob");
         Dog  tom = new Dog("tom","brown","Lab",4, bob);
        System.out.println(tom);
        
	}
}
