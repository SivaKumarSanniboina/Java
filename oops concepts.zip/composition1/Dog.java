package com.htc.composition1;

public class Dog {

	
	private String name;
	private String colour;
	private String breed;
	private int age;
	//every dog belongs to the human
	private Human owner;
	public Dog(String name,String colour,String breed,int age,Human owner) {
		this.name=name;
		this.colour=colour;
		this.breed=breed;
		this.age=age;
		this.owner=owner;
		
	}
	@Override
	public String toString() {
		return "Dog [name=" + name + ", colour=" + colour + ", breed=" + breed + ", age=" + age + ", owner=" + owner
				+ "]";
	}
	
	}
	
	
		
	

