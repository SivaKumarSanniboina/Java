package com.htc.composition1;

public class Human {
	
 private String name;
 public Human(String name) {
	 this.name=name;
 }
public String toString() {
	return name;
	
}
}
