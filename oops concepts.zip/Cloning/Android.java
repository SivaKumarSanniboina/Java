package com.htc.Cloning;

public class Android implements Cloneable {

	
	public int Ram;
	public String Design;
	public int   batterycapacity;
	public String os;
	public int camerafutures;
	
	protected Android clone()throws CloneNotSupportedException{
		return (Android)super.clone();
		
	}
	
	
	

	
}

   
   

