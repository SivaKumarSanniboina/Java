package com.htc.Cloning;

public class Main {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
       Android Ad = new Android();
       Ad.camerafutures=104;
       Ad.Ram=12;
       Ad.Design="Metalicfinish";
       Ad.os="Android";
       Ad.batterycapacity=4;
       
       System.out.println(Ad.camerafutures);
       System.out.println(Ad.batterycapacity);
       System.out.println(Ad.Design);
       System.out.println(Ad.os);
       System.out.println(Ad.Ram);
       
       System.out.println("-----------------------------------------------");
       
       Android w = Ad.clone();

       System.out.println(w.camerafutures);
       System.out.println(w.batterycapacity);
       System.out.println(w.Design);
       System.out.println(w.os);
       System.out.println(w.Ram);
       
	}

}
