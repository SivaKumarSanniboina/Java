package com.htc.MarkerInterface;

public class ImplMarkerInterface implements MyMarkerInterface{

}
