package com.htc.MarkerInterface;

public interface MyMarkerInterface {

}
