package com.htc.MarkerInterface;

public class FunctionalityMarkerInterface {
	
	static void isMarker(Object  obj) {
		if(obj instanceof MyMarkerInterface) {
			System.out.println("It is the object of My Marker interface");
		}
	}


public static void main(String[] args) {
	ImplMarkerInterface impl= new ImplMarkerInterface();
	isMarker(impl);
}
}