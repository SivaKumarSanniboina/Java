package com.htc.Anonymous;

public class AnonymousDemo {
	 public void createClass() {

	      // creation of anonymous class extending class Polygon
	      Polygon p1 = new Polygon() {
	         public void display() {
	            System.out.println("Invoking the anonymous class method.");
	         }
	      };
	      p1.display();  // invoke the anonymous class method
	   }
}
