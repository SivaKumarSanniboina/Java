package com.htc.Anonymous;


public class AnonymousMain {
	 public static void main(String[] args) {
	       AnonymousDemo an = new AnonymousDemo();
	       an.createClass();
	   }
}
