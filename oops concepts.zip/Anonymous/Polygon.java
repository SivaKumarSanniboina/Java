package com.htc.Anonymous;

public class Polygon {
	public void display() {
	      System.out.println("Inside the Polygon class");
	   }
}
