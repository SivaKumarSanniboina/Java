package com.htc.Interface;
//Java program to illustrate the
//concept of interface 

public interface IShape
{
// abstract method
public void draw();
public double area();
}
