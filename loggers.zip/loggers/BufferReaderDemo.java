package com.htc.loggers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.log4j.Logger;

public class BufferReaderDemo {
	public static Logger logger = Logger.getLogger(BufferReaderDemo.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       File file =new File("myfolder","formated");
       logger.info("file and folder created successfully ");
   	
    	BufferedReader br=null;
       
       try {	 
            br=new BufferedReader(new FileReader(file)); 
       
           while(true) {
                  String line =br.readLine();
                  if (line==null)
                	  break;
                  System.out.println(line);
                  logger.info("printed line by line ");
	
	         }
       }catch(FileNotFoundException e) {
    	   logger.error("Error:"+e.toString());
    	  
       }catch(IOException e) {
    	   logger.error("Error:"+e.toString());
       }
       finally {
    	       try
    	       {
    	    	   if (br!=null)
    	    		   br.close();
    	    	   logger.info("file closed successfully");
    	    	   
    	       }catch (IOException e) {
    	    	   logger.error("Error:"+e.toString());
    	       }
       }
	}
}
	


