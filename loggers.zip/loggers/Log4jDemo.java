package com.htc.loggers;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class Log4jDemo {
public static void main(String[] args) {
	Logger logger = Logger.getLogger(Log4jDemo.class);
	logger.log(Level.INFO, "information message");
	logger.info("info message");
	logger.error("error message");
	logger.fatal("fatal error");
	logger.debug("Debug message");
	logger.warn("warning message");
	logger.trace("Trace");
	
	
	
	
	
}   
}
