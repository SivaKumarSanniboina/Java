package com.basic.exercise1;

public class AllSundays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int day=1;
		while(day<=31)
		{
			System.out.println("Jan "+ day + " is " + " Sunday");
			day=day+7;
		}
		
		}
		
		

}
