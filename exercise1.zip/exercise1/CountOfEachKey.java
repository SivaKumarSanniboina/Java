package com.basic.exercise1;

public class CountOfEachKey {

	public static void main(String[] args) 
	{
		int count=0;
		int k[]= {12,54,44,20,19};
		int O[]={12, 54, 19, 20 ,44, 19, 14, 54, 20, 19};
		for(int i=0;i<5;i++)
		{
			count=0;
			for(int j=0;j<10;j++)
			{
				if(k[i]==O[j])
				{
					count++;
				}
			}
			System.out.print(count+" ");
		}
	}

}
