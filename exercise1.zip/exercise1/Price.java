package com.basic.exercise1;

import java.util.Scanner;

public class Price {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double a[][] = new double[][]{
			{1,225,500.75},
			{2,226,600.80},
			{3,227,715.00},
			{4,228,860.20},
			{5,229,698.35},
			{6,230,744.20},
			{7,231,125.50},
			{8,232,263.40},
			{9,233,640.00},
			{10,234,400.00}};
		int i,j,id;
		double n=0;
		for(i=0;i<10;i++)
		{
			for(j=0;j<=2;j++)
			{
				System.out.println(+a[i][j]);
			}
		}
		System.out.println("Enter the productId:");
		id = sc.nextInt();
	    for(i=0;i<10;i++) 
			{
				j=1;
			    if(id==a[i][1])
			    {
				n=a[i][2];	
			    }
			}
			    System.out.println("price is: "+n);
			
		if(n==0)
		{
			System.out.println("Invalid product");
		}
	

		
	}

}
