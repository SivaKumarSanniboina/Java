package com.basic.exercise1;

import java.util.Scanner;

public class ElectricityBill {

	public static void main(String[] args) 
	{
		int units=0,billAmount=0;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the unit value:");
		units=sc.nextInt();
		
		if(units>1000)
		{
			System.out.println(billAmount=units*10);
			
		}
		else if(units>500)
		{
			System.out.println(billAmount=units*5);
		}
		else if(units>200)
		{
			System.out.println(billAmount=units*2);
		}
		else
		System.out.println(billAmount=units*1);
	}
}
