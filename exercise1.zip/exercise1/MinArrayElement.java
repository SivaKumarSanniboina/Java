package com.basic.exercise1;

public class MinArrayElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={33,1,4,5};
		int min=a[0];
		int i;
		
		for(i=0;i<a.length;i++)
		{
			if(a[i]<min)
			{
				min=a[i];
			}
			
		}
		System.out.println(min);
	}

}
