package com.basic.exercise1;

import java.util.Scanner;

public class SumOfFact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,n,fact=1,sum=0;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		n=sc.nextInt();
		
		for(i=1;i<=n;i++)
		{
			fact=1;
			for(j=1;j<=i;j++)
			{
				fact=fact*j;
			}
			sum=sum+fact;
			
		}
		System.out.print(sum);

	}

}
