package com.basic.exercise1;

import java.util.Scanner;

public class ModeofTransport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean priority;
		int distance=0,weight=0;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Is your priority urgent? true or False:");
		priority=sc.nextBoolean();
		
		System.out.println("Enter the distance:");
		distance=sc.nextInt();
		
		System.out.println("Enter the weight:");
		weight=sc.nextInt();
		
		if(priority==true)
		{
			if(distance<50)
			{
				if(weight<100)
				{
				System.out.println("Dispatch by Van");
				}
			}
		}
		else if(priority==false)
		{
			if(distance<=250)
			{
				if(weight>5)
				{
					System.out.println("Dispatch by Lorry");
				}
				if(weight<=5)
				{
					System.out.println("Dispatch by Post");
				}
				
			}
			
		}else
		System.out.println("Train");
		
	}

}
