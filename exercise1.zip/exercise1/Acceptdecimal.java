package com.basic.exercise1;

import java.util.Scanner;

public class Acceptdecimal {

	public static void main(String[] args)
	{
		int num,temp,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a decimal number:");
		num=sc.nextInt();
		
		while(num>=1)
		{
			temp=num%10;
			sum=sum+temp;
			num=num/10;
		}
		
		System.out.println(sum);

	}

}
