package com.basic.exercise1;

import java.util.Scanner;

public class PasswordValidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
//		String password;
		char password[]=new char[100];
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Password:");
		password=sc.next().toCharArray();
		
		int plen = password.length;	
//		boolean flag = true;
		for(i=0;i<plen;i++)
		{
		if(plen>10||plen<50)
		{
			if(password[0]!=' ' ||password[plen-1]!=' ')
			{
			
						if(password[i]=='_')
							{
							
									System.out.println("Password is valid");
								
						
							}	
						

							
			}

				
			
			
		}	
		else
			System.out.println("Invalid");

		}
		
		
	}


}
