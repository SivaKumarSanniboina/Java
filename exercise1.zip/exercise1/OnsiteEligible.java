package com.basic.exercise1;

import java.util.Scanner;

public class OnsiteEligible {


	public static void main(String[] args) 
	{
		boolean passport,communication,feedback;
		int experience = 0,age = 0;
		
		Scanner pass=new Scanner(System.in);
		System.out.println("Do you have passport? true or false:");
		passport=pass.nextBoolean();

		Scanner comm=new Scanner(System.in);
		System.out.println("Do you have good communication? true or false:");
		communication=comm.nextBoolean();

		Scanner feed=new Scanner(System.in);
		System.out.println("Do you have good feedback? true or false:");
		feedback=feed.nextBoolean();
		
		Scanner exp=new Scanner(System.in);
		System.out.println("How much exp do you have?:");
		experience=exp.nextInt();

		Scanner ag=new Scanner(System.in);
		System.out.println("What is your age?:");
		age=ag.nextInt();
		

		if(passport==true)
		{
			if(communication==true)
			{
				if(feedback==true)
				{
					if(experience>=2)
					{
						if(age>=22)
						{
							System.out.println("emp is eligible for onsite");
						}
						else 
						System.out.println("Emp is not eligible because of less age");
					}
					else 
					System.out.println("Emp is not eligible beacause of less experience");
				}
				else 
				System.out.println("Emp is not eligble because of bad feedback");
			}
			else 
			System.out.println("Emp is not eligible beacause of bad communication");
		}
		else 
		System.out.println("Emp is not eligible beacause of no passport");
	}
}
			