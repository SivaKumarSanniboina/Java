package com.basics.exercise1;

import java.util.Scanner;

public class FactRange {

	public static void main(String[] args) {
			
		int begin,end;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter begining vaue: ");
		begin=sc.nextInt();
		
		System.out.println("Enter ending vaue: ");
		end=sc.nextInt();
		
		 int fact = 1;
	        for (int i = 1; i < begin; i++) {
	            fact = fact * i;
	        }
	 
	        for (int i = begin; i <= end; i++)
	        {
	            fact = fact * i;
	            System.out.println("factorial of "+i+" is "+fact);
	        }
		
	}

}
