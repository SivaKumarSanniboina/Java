package com.basics.exercise1;

import java.util.Scanner;

public class BankIntrestDetails10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String bank;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Bank name:");
		bank=sc.next();
		
		switch(bank){
		
		 case "SBI":  bank = "Intrest is 7";
         break;
         
		 case "ICICI":  bank = "Intrest is 8";
         break;
         
		 case "BOI":  bank = "Intrest is 5";
         break;
		 case "HDFC":  bank = "Intrest is 10";
         break;
		 default: bank = "Invalid bank";
         break;
         
		
		}
		System.out.println(bank);
		

	}

}
