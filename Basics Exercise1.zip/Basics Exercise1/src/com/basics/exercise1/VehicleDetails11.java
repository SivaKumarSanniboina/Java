package com.basics.exercise1;

import java.util.Scanner;

public class VehicleDetails11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String vehicleType;
		int amount;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the vehicle type:");
		vehicleType=sc.next();
		
		System.out.println("Enter the Amount");
		amount=sc.nextInt();
		
		if(vehicleType=="bike" && amount<=100000)
		{
			System.out.println("Hero Honda splender+");
		}
		else if(vehicleType=="bike" && amount>=100000)
		{
			System.out.println("Pulsor 150");
		}
		else if(vehicleType=="bike" && amount>=200000)
		{
			System.out.println("DUKE");
		}
		else if(vehicleType=="bike" && amount>=500000)
		{
			System.out.println("BMW");
		}
		else
			System.out.println("Bucycle");
	

	}

}
