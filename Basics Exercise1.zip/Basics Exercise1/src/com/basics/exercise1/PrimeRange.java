package com.basics.exercise1;

import java.util.Scanner;

public class PrimeRange {

	public static void main(String[] args) 
	{
		int n1,n2,i,j,count=0;

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Lowest value: ");
		n1=sc.nextInt();
		
		System.out.println("Enter the Highest value: ");
		n2=sc.nextInt();
		
		for(i=n1;i<=n2;i++)
		{
			for(j=2;j<i;j++)
			{
				if(i%j==0)
				{
					count = 0;
					break;
				}
				else
				{
					count=1;
				}
			}
			if(count==1)
			{
				System.out.print(i+" ");
			}
		}
		
		
	}

}
