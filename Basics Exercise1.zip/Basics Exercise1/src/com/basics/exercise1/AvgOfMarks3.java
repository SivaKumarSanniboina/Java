package com.basics.exercise1;

public class AvgOfMarks3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks[]=new int[5];
		marks[0]=40;
		marks[1]=50;
		marks[2]=60;
		marks[3]=70;
		marks[4]=80;
		

		int i;
		float total=0,avg;
		
		for(i=0;i<marks.length;i++)
		{
			total=total+marks[i];
		}
		avg=total/5;
		System.out.println("Average is: "+avg);
		
		 if(avg>=80)
	        {
	            System.out.print("Grade A");
	        }
	        else if(avg>=60 && avg<80)
	        {
	           System.out.print("Grade B");
	        } 
	        else if(avg>=40 && avg<60)
	        {
	            System.out.print("Grade C");
	        }
	        else
	        {
	            System.out.print("Grade D");
	        }
		
		
		

	}

}
