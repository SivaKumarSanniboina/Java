	package com.basics.exercise1;

public class CorrectTheCode9 {

	public static void main(String[] args) {

		//i)
		byte a=10;
        byte b=20;
        byte c=(byte) (a*b);
        System.out.println(c);

        
        //ii)
        int SIZE=10;
        for(int i=0;i<SIZE;i++){
                System.out.println(i);
         }
         SIZE=20;
         for(int j=SIZE;j>0;j--){
               System.out.print(j+" ");
         }

		

	}

}
