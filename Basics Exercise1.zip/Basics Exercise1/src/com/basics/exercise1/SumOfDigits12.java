package com.basics.exercise1;

import java.util.Scanner;

public class SumOfDigits12 {

	public static void main(String[] args) {
		
		int num,temp,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		num=sc.nextInt();
		
		while(num>=1)
		{
			temp=num%10;
			sum=sum+temp;
			num=num/10;
		}
		
		System.out.println(sum);
	}

}
