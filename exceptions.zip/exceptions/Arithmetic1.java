package com.exercise10.exceptions;

public class Arithmetic1 
{

	public static void main(String[] args) 
	{
		
			int a = 10, b = 0;
			System.out.println("Result: "+ a/b);
	}
			

	
}
