package com.exercise10.exceptions;

import java.util.Scanner;

public class Exception7 
{
	
		public static void square() 
		{
			System.out.println("Square method");
		}
	
		public static void cube() 
		{
			System.out.println("cube method");
		}
	static void callCubeOrSquare(int num) 
	{
		
	}
	static void IllegalArgumentException()
	{
		System.out.println("IllegalArgumentException");
	}

	public static void main(String[] args) 
	{
		int num;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		num=sc.nextInt();
		
		callCubeOrSquare(num);
		if(num==2)
		{
			square();
		}
		else if(num==3)
		{
			cube();
		}
		else
			IllegalArgumentException();
			
		

	}

}
