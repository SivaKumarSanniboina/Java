package com.exercise10.exceptions;

public class Handling2 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		try 
		{
			int a = 10, b = 0;
			System.out.println("Result: " + a/b);
		} 
		catch (ArithmeticException ae) 
		{
			System.out.println("Arithmetic Exception: cannot divide by 0");
		}
		System.out.println("Continuing execution...");

	}

}
