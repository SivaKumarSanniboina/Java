package com.exercise10.exceptions;

public class SemTesting9 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		  String strs[] = new String[3]; 
	   		
	       for(int j=0;j<3;j++)
	                  {
	                   try
	                   {
	                    strs[j] = "htc-"+args[j].trim(); 
	                   }
	                   catch(ArrayIndexOutOfBoundsException ae)
	                   {
	                     strs[j] = "htc";
	                   }
	                  }
	                 System.out.println(java.util.Arrays.toString(strs));  


	}

}
