package com.exercise10.exceptions;

public class ExceptionInInitializerError3_2 {
	static int i=20/0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(i);

	}

}
