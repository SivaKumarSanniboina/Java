package com.exercise.collections;

import java.util.LinkedHashSet;

public class LinkedHashSet1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 LinkedHashSet<String> lhs= new LinkedHashSet<String>();
		 lhs.add("s");
		 lhs.add("i");
		 lhs.add("v");
		 lhs.add("a");
		 lhs.add(" ");
		 lhs.add("k");
		 lhs.add("u");
		 lhs.add("m");
		 lhs.add("a");
		 lhs.add("r");
		 
		 for (String itr : lhs) 
		 {
	          System.out.println(itr);
	     }
		 
		 

	}

}
