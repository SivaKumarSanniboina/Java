package com.exercise.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;


public class Collection8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	      Collection col = new ArrayList<>();
	      col.add("one");
	      col.add("two");
	      col.add("four");
	      col.add("one");
	      col.add("four");
	      Set set = new HashSet<>(col);
	      System.out.println(set); 

	}

}
