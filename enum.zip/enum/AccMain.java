package com.htc.EnumDemo.Demo;

public class AccMain {
	public static void main(String[] args) {
		Account account =new Account();
		account.setAccName("Gowtham");
		account.setAccNo("B100122");
		account.setType(AccType.SAVINGS);
		account.setBalance(12000);
		System.out.println(account);
	}

}
