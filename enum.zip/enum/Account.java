package com.htc.EnumDemo.Demo;

public class Account {
	private String accNo;
	private String accName;
	private AccType type;
	private double balance;
	public Account()
	{

		super();
}
	
	public Account(String accNo, String accName, AccType type, double balance) {
		super();
		this.accNo = accNo;
		this.accName = accName;
		this.type = type;
		this.balance = balance;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public AccType getType() {
		return type;
	}

	public void setType(AccType type) {
		this.type = type;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accName=" + accName + ", type=" + type + ", balance=" + balance + "]";
	}

	
}
