package com.htc.EnumDemo.Demo;

public enum AccType {
	LOAN,SAVINGS,JOINT

}
