package com.htc.filecreation;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PrintWriterDemo {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
   File file = new File("myfolder","formatted");
   PrintWriter pw=null;
   try {
	 pw =new PrintWriter(new FileWriter(file));
	pw.println("This is the first line");
	pw.println("This is the Second line");
	pw.println("This is the Third line");
	pw.println("This is the last line");
	
	
	
			
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
   finally {
	   pw.close();
   }
  
   
   
	}

}
