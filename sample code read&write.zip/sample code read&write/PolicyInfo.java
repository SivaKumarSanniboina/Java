package com.htc.IODemo.Files;

import java.util.Date;

public class PolicyInfo {
	private String policyNo;
	private String policyHolderName;
	private Date issueDate;
	private double premium;
	
	public PolicyInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PolicyInfo(String policyNo, String policyHolderName, Date issueDate, double premium) {
		super();
		this.policyNo = policyNo;
		this.policyHolderName = policyHolderName;
		this.issueDate = issueDate;
		this.premium = premium;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public String getPolicyHolderName() {
		return policyHolderName;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public double getPremium() {
		return premium;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public void setPremium(double premium) {
		this.premium = premium;
	}

	@Override
	public String toString() {
		return "PolicyInfo [policyNo=" + policyNo + ", policyHolderName=" + policyHolderName + ", issueDate="
				+ issueDate + ", premium=" + premium + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((policyNo == null) ? 0 : policyNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PolicyInfo other = (PolicyInfo) obj;
		if (policyNo == null) {
			if (other.policyNo != null)
				return false;
		} else if (!policyNo.equals(other.policyNo))
			return false;
		return true;
	}

}
