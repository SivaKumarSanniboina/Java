package com.htc.IODemo.Files;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.Buffer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.sun.tools.javac.util.List;

public class BufferedMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<PolicyInfo> policyList = new ArrayList<PolicyInfo>();
		File file=new File("myfolder"+File.separator+"policyinfo");
		BufferedReader br= null;
		
	
		    try {
				br=new BufferedReader(new FileReader(file));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			while(true) {
				String line = null;
				try {
					line = br.readLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(line==null)
					break;
				
				
				
				String[]policyFields = line.split(",");
				if(policyFields.length==4) {
					String policyNo=policyFields[0];
					String policyHolderName=policyFields[1];
					String issuedate = policyFields[2];
					String premium = policyFields[3];
					
					//validate the fields here..
					SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
					try {
						policyList.add(new PolicyInfo(policyNo,policyHolderName,sdf.parse(issuedate),Double.parseDouble(premium)));
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				for(PolicyInfo p:policyList){
					System.out.println(p);
					System.out.println("-------------------------------------------------------------------------------------------");
					
				}
				writeFormattedRecord(policyList);
			}
			}
			         
			
		

	private static void writeFormattedRecord(ArrayList<PolicyInfo> policyList) {
		
		// TODO Auto-generated method stub
		try {
			PrintWriter pw = new PrintWriter(new FileWriter("myfolder"+File.separator+"policyreport"));
			pw.printf("%70s\n", "policy info report");
			pw.printf("%70s\n\n", ".....................");
			pw.printf("%120s\n", "Date:10-10-2018");
			pw.printf("%20s%-30s %15s %25s\n", ".......................","....................",".............",".............");
			pw.printf("%20s%-30s %15s %25s\n", "PolicyNo",              "Policy Holder Name",    "Issuedate",    "premium");
			pw.printf("%20s%-30s %15s %25s\n", ".......................","....................",".............",".............");
			
			SimpleDateFormat sdf= new SimpleDateFormat("MM/dd/yyyy");
			for(PolicyInfo p: policyList) {
				pw.printf("%20s%-30s %15s %10s\n",p.getPolicyNo(),p.getPolicyHolderName(),p.getIssueDate(),p.getPremium());
		} 
			pw.close();
		}
			catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	}


			
			
	




