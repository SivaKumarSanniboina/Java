package com.htc.jdbccrud.entity;


	import java.io.Serializable;

	public class Employee implements Serializable{
		
		private String empId;
		private String empName;
		private String email;
		private String phoneno;
		private int salary;
		public Employee() {}
		public Employee(String empId, String empName, String email, String phoneno, int salary) {
			super();
			this.empId = empId;
			this.empName = empName;
			this.email = email;
			this.phoneno = phoneno;
			this.salary = salary;
		}
		public String getEmpId() {
			return empId;
		}
		public void setEmpId(String empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPhoneno() {
			return phoneno;
		}
		public void setPhoneno(String phoneno) {
			this.phoneno = phoneno;
		}
		public int getSalary() {
			return salary;
		}
		public void setSalary(int salary) {
			this.salary = salary;
		}
		@Override
		public String toString() {
			return "Employee [empId=" + empId + ", empName=" + empName + ", email=" + email + ", phoneno=" + phoneno
					+ ", salary=" + salary + "]";
		}
		
		}
		

	


