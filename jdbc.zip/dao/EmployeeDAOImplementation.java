package com.htc.jdbccrud.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.htc.jdbccrud.dbconnect.DBConnect;
import com.htc.jdbccrud.entity.Employee;

public class EmployeeDAOImplementation implements EmployeeDAO{
	
	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		boolean insertFlag = false;
		if(emp!=null) {
		Connection con = DBConnect.getConnection();
		try {
			PreparedStatement stmt = con.prepareStatement("insert into employee values(?,?,?,?,?)");
			stmt.setString(1, emp.getEmpId());
			stmt.setString(2, emp.getEmpName());
			stmt.setString(3, emp.getEmail());
			stmt.setString(4, emp.getPhoneno());
			stmt.setInt(5, emp.getSalary());
			int result=stmt.executeUpdate();
			insertFlag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		return insertFlag;
	}

	
	@Override
	public boolean deleteEmployee(String empId) {
		// TODO Auto-generated method stub
		boolean deleteFlag = false;
		Connection con = DBConnect.getConnection();
		PreparedStatement stmt;
		try {
			stmt = con.prepareStatement("delete from table where empid = ?");
			stmt.setString(1, empId);
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return deleteFlag;
	}

	@Override
	public Employee getEmployeeById(String empId) {
		// TODO Auto-generated method stub
		Employee emp = new Employee();
		Connection con = DBConnect.getConnection();
		try {
			PreparedStatement stmt = con.prepareStatement("select empid,empname,email,phoneno,salary from employee where empid=?");
			stmt.setString(1, empId);
			ResultSet rs = stmt.executeQuery();
			while(rs.next())
			{
				emp.setEmpId(rs.getString(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmail(rs.getString(3));
				emp.setPhoneno(rs.getString(4));
				emp.setSalary(rs.getInt(5));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		List<Employee> emplist = new ArrayList<Employee>();
		
		Connection con = DBConnect.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select empid,empname,email,phoneno,salary from employee");
			while(rs.next())
			{
				Employee emp = new Employee();
				emp.setEmpId(rs.getString(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmail(rs.getString(3));
				emp.setPhoneno(rs.getString(4));
				emp.setSalary(rs.getInt(5));
				emplist.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return emplist;
	}

}
