package com.htc.jdbccrud.dao;

import java.util.List;

import com.htc.jdbccrud.entity.Employee;

public interface EmployeeDAO {
	
	public boolean addEmployee(Employee emp);
	
	public boolean deleteEmployee(String empId);
	public Employee getEmployeeById(String empId);
	public List<Employee> getAllEmployee();

}
