package com.htc.jdbccrud.main;

	import com.htc.jdbccrud.dao.EmployeeDAO;
	import com.htc.jdbccrud.dao.EmployeeDAOImplementation;
	import com.htc.jdbccrud.entity.Employee;

	public class Main {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Employee emp1 = new Employee("E01", "anu", "anu@htcindia.com", "9874562124", 874552);
			Employee emp2 = new Employee("E02", "anitha", "anitha@htcindia.com", "987443345", 844552);
			Employee emp3 = new Employee("E03", "sam", "sam@htcindia.com", "9874563210", 874552);
			Employee emp4 = new Employee("E04", "vijay", "vijay@htcindia.com", "9874563210", 874552);
			
			EmployeeDAO daoobj = new EmployeeDAOImplementation();
			
			daoobj.addEmployee(emp1);
			daoobj.addEmployee(emp2);
			daoobj.addEmployee(emp3);
			daoobj.addEmployee(emp4);
			
		
			
			System.out.println(daoobj.getAllEmployee());
			
			
			
			System.out.println(daoobj.getEmployeeById("E01"));
		}

	}



