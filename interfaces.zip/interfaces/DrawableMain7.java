package com.exercise.interfaces;

public class DrawableMain7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub]
		Drawable7 d7=new Circle7();
		d7.draw();

	}

}
