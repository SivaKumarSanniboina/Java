package com.exercise.interfaces;

public class Animal6 implements AnimalEat6, AnimalTravel6 
{
	public void eat() {
	      System.out.println("Animal is eating");
	   }
	   public void travel() {
	      System.out.println("Animal is travelling");
	   }

}
