package com.exercise.interfaces;

public interface OneIf
{
	static String sayOnce(String str) {
		// TODO Auto-generated method stub
		return null;
	}

}
