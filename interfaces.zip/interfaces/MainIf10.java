package com.exercise.interfaces;

public class MainIf10 implements OneIf,TwoIf
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
	//	sayOnce("h");

	}



	

}
