package com.exercise.interfaces;

public class CalculatorMain1 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		 Calculator1 cl = new Calculator1();
		 
		  System.out.println(cl.add(2, 2)+" " +cl.sub(50 , 10)+" " +cl.mul(2, 2)+" " +cl.div(20, 5));

	}

}
