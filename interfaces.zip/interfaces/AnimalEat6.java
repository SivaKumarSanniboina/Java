package com.exercise.interfaces;

public interface AnimalEat6 
{
	void eat();

}
