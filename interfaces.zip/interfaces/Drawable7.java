package com.exercise.interfaces;

public interface Drawable7 
{
	void draw();

}
