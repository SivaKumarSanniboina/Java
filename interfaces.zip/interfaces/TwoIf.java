package com.exercise.interfaces;

public interface TwoIf 
{
    static String sayOnce(String str) {
		// TODO Auto-generated method stub
		return null;
	}

}
