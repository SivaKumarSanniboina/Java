package com.exercise.interfaces;

public class AnimalMain6 {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Animal6 a6 = new Animal6();
	      a6.eat();
	      a6.travel();

	}

}
