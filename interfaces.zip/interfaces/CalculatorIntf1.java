package com.exercise.interfaces;

public interface CalculatorIntf1
{
	int add(int a,int b);
    int sub(int a,int b);
    int  mul(int a,int b);
    int div(int a,int b);
}
