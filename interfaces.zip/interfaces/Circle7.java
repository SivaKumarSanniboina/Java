package com.exercise.interfaces;

public class Circle7 implements Drawable7
{
	public void draw()
	{
		System.out.println("drawing circle");
	}  

}
