package com.htc.productload.main;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.htc.productload.dao.IProductImpl;



public class MainClass {

	
	public static Logger logger =Logger.getLogger(MainClass.class);
	public static void main(String[] args) throws SecurityException, FileNotFoundException, IOException, SQLException
	{
		
		IProductImpl impl = new IProductImpl();
		
		impl.readFileFromFile();
		
		System.out.println("Load Operation Done!!");
		impl.readFileFromFile1();
		System.out.println("UnLoad Operation Done!!");
		 logger.info("table created successfully");
		 
		
	}

}
	


