package com.htc.productload.dao;

import java.io.IOException;
import java.sql.SQLException;


import com.htc.productload.entity.ProductList;

public interface IProductInterface 
{
	public void readFileFromFile() throws IOException, SQLException;
	public boolean insertToTable(ProductList obj) throws SQLException, IOException;
	

}
