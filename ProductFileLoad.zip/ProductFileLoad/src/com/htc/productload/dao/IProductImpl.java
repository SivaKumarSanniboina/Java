package com.htc.productload.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.htc.productload.dbconnection.DbConnector;
import com.htc.productload.entity.ProductList;
import com.htc.productload.main.MainClass;


public class IProductImpl 
{
	public static Logger logger =Logger.getLogger(MainClass.class);
	public void readFileFromFile() throws IOException, SQLException 
	{
		// TODO Auto-generated method stub
           
		File file = new File("src\\ProductList.xlsx");


		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0); 
		Iterator<Row> itr = sheet.iterator();

		Row row = itr.next();
		int insert_table_counter = 0;
		int read_file_counter = 0;
		while (itr.hasNext()) 
		{
			row = itr.next();
			Iterator<Cell> cellIterator = row.cellIterator(); 

			
			while (cellIterator.hasNext()) {
				
				Cell cell = cellIterator.next();
				int productId = (int)cell.getNumericCellValue();

				cell = cellIterator.next();
				String productName = cell.getStringCellValue();

				cell = cellIterator.next();
				int price = (int) cell.getNumericCellValue();
				
				cell = cellIterator.next();
				String status = cell.getStringCellValue();

				
				 
				if(status.equals("active"))
				{
					
           	  ProductList obj = new ProductList(productId,productName,price,status);
           	  insertToTable(obj); 
           	  logger.info("inserted to table");
             
		           }
			}
		}
	}
	

	private boolean insertToTable(ProductList obj) throws SQLException, IOException{
		// TODO Auto-generated method stub
		
		
			// TODO Auto-generated method stub

			boolean status = false;

			Connection con = DbConnector.getConnection();
					
			PreparedStatement ps = con.prepareStatement(
					"INSERT INTO Productdetails(productId, productName, price, status) VALUES(?,?,?,?)");

			ps.setInt(1, obj.getProductId());
			ps.setString(2, obj.getProductName());
			ps.setDouble(3, obj.getPrice());
			ps.setString(4, obj.getStatus());
			status = !ps.execute(); 

			return status;
		
	}
	public void readFileFromFile1() throws IOException, SQLException {
		// TODO Auto-generated method stub
            ArrayList<ProductList> criteria=new ArrayList<>();
            ArrayList<ProductList> statuss =new ArrayList<>();
		File file = new File("src//ProductList.xlsx");


		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0); 
		Iterator<Row> itr = sheet.iterator();

		Row row = itr.next();
		int insert_table_counter = 0;
		int read_file_counter = 0;
		while (itr.hasNext()) 
		{
			row = itr.next();
			Iterator<Cell> cellIterator = row.cellIterator(); 

			
			while (cellIterator.hasNext()) {
				
				Cell cell = cellIterator.next();
				int productId = (int)cell.getNumericCellValue();

				cell = cellIterator.next();
				String productName = cell.getStringCellValue();

				cell = cellIterator.next();
				int price = (int) cell.getNumericCellValue();
				
				cell = cellIterator.next();
				String status = cell.getStringCellValue();

				
				 if(status.equals("active")) {
	            	  ProductList obj = new ProductList(productId,productName,price,status);
	            	  criteria.add(obj);
	            	  System.out.println(criteria);
	            	  writeFile(criteria);
	              }
	              else{
	            	  ProductList obj = new ProductList(productId,productName,price,status);
	            	   
	            	  statuss.add(obj);
	            	  }
	            	  System.out.println(statuss);
	            	  writeFile1(statuss);
			}
		}
	}

	private void writeFile1(ArrayList<ProductList> statuss) throws IOException {
		// TODO Auto-generated method stub
		XSSFWorkbook wb = new XSSFWorkbook();

		XSSFSheet spreedsheet = wb.createSheet("ExpireDetails");
		FileOutputStream fos = new FileOutputStream("ExpireDetails.xlsx");
		XSSFRow row;
		int rowno = 0;
		int cellno = 0;

		row = spreedsheet.createRow(rowno);
		Cell cell = row.createCell(cellno);

		cell = row.createCell(cellno);
		cell.setCellValue("productId");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("productName");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("price");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("status");
		cellno++;
		rowno++;

		for (ProductList cc : statuss) {
			row = spreedsheet.createRow(rowno);

			cellno = 0;
			cell = row.createCell(cellno);
			cell.setCellValue(cc.getProductId());
			cellno++;

			cell = row.createCell(cellno);
			cell.setCellValue(cc.getProductName());
			cellno++;

			cell = row.createCell(cellno);
			cell.setCellValue(cc.getPrice());
			cellno++;

			cell = row.createCell(cellno);
			cell.setCellValue(cc.getStatus());
			cellno++;
			rowno++;
		}

		wb.write(fos);

		fos.close();
		System.out.println("Excel File Created!!");

		
		
	}

	private void writeFile(ArrayList<ProductList> criteria) throws IOException {
		// TODO Auto-generated method stub
		XSSFWorkbook wb = new XSSFWorkbook();

		XSSFSheet spreedsheet = wb.createSheet("ProductDetails");
		FileOutputStream fos = new FileOutputStream("ProductDetails.xlsx");
		XSSFRow row;
		int rowno = 0;
		int cellno = 0;

		row = spreedsheet.createRow(rowno);
		Cell cell = row.createCell(cellno);

		cell = row.createCell(cellno);
		cell.setCellValue("productId");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("productName");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("price");
		cellno++;

		cell = row.createCell(cellno);
		cell.setCellValue("status");
		cellno++;
		rowno++;

		for (ProductList cc : criteria) {
			row = spreedsheet.createRow(rowno);

			cellno = 0;
			cell = row.createCell(cellno);
			cell.setCellValue(cc.getProductId());
			cellno++;

			cell = row.createCell(cellno);
			cell.setCellValue(cc.getProductName());
			cellno++;

			cell = row.createCell(cellno);
			cell.setCellValue(cc.getPrice());
			cellno++;

			cell = row.createCell(cellno);
			cell.setCellValue(cc.getStatus());
			cellno++;
			rowno++;
		}

		wb.write(fos);

		fos.close();
		System.out.println("Excel File Created!!");

	}



}
