package com.classesandmethods.exercise3;

public class Employee extends Company
{
	public int empId;
	   public int getempId() {
		   return 1001;
	   }
	public String name;
	public String getname() {
		  return "Ramesh";
	}
	public int salary;
	public int getsalary() {
		return 20000;
	}
	public String designation;
	public String getdesignation() {
		return "ProgrammerAnalyst Trainee";
	}

}
