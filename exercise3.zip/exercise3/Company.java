package com.classesandmethods.exercise3;

public class Company 
{
	 public String companyName;
     public String getcompanyName() 
     {
    	 return "HTC global services";
     }


     Department[] depts;
	
	public int getempId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getdeptId() {
		// TODO Auto-generated method stub
		return 556;
	}

	public String getname() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getsalary() {
		// TODO Auto-generated method stub
		return 25000;
	}

	public String getdesignation() {
		// TODO Auto-generated method stub
		return "Programmer Analyst Trainee";
	}

}
