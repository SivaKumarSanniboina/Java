package com.classesandmethods.exercise3;

public class MainCompany {

	public static void main(String[] args) 
	{
		Company c=new Employee();
		
	    System.out.println(+c.getsalary()+" "+c.getdesignation()+" "+c.getdeptId()+" "+c.getname());

	}

}
