package com.classesandmethods.exercise3;

public class Department extends Company
{
	 public int deptId;
	   public int getdeptId() {
		   return 556;
	   }
	public String deptName;
	public String getdeptName() {
		return "IT";
	}
	
	  Employee[] emps;


}
