package com.classesandmethods.exercise3;

public class Static7 

{
	static String CompanyName;
	
	static
	{
		CompanyName="HTC";
	}

	public static String getCompanyName() {
		return CompanyName;
	}

	public static void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public static void main(String []args)
	{
		System.out.println(CompanyName);
	}

}
