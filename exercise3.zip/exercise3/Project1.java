package com.classesandmethods.exercise3;

public class Project1 {
	private int projectId;
	private	String projectName;
	private String projectHead;
	
	

	public int getProjectId() {
		return projectId;
	}



	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}



	public String getProjectName() {
		return projectName;
	}



	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}



	public String getProjectHead() {
		return projectHead;
	}



	public void setProjectHead(String projectHead) {
		this.projectHead = projectHead;
	}



	@Override
	public String toString() {
		return "Project1 [projectId=" + projectId + ", projectName=" + projectName + ", projectHead=" + projectHead
				+ "]";
	}



	public static void main(String[] args)
	{
		Project1 p1=new Project1();
		p1.setProjectId(1);
		p1.setProjectName("Ram");
		p1.setProjectHead("Leela");
		System.out.println(p1);
		
		
	}

}
