package com.htc.tabletofile.dao;

import java.io.IOException;
import java.sql.SQLException;


import com.htc.tabletofile.entity.EmployeeList;
public interface IEmployeeInterface 
{
	public void readFileFromFile() throws IOException, SQLException;
	public boolean insertToTable(EmployeeList obj) throws SQLException, IOException;
	

}
