package com.htc.tabletofile.main;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.htc.tabletofile.dao.IEmployeeImpl;
public class MainClass {
	public static Logger logger =Logger.getLogger(MainClass.class);
	
	public static void main(String[] args) throws SecurityException, FileNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		
		IEmployeeImpl impl = new IEmployeeImpl();
		
		impl.readFileFromFile();
		
		System.out.println("Load Operation Done!!");
		 logger.info("table created successfully");
		 
	}
}
