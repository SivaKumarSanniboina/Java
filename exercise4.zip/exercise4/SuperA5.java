package com.InheriandAbstract.exercise4;

public class SuperA5 
{
    public void calculate(int k)
    {
    	
    }
    


}
