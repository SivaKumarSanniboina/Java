package com.InheriandAbstract.exercise4;

public class MainShape3 {

	public static void main(String[] args)
	{
		Rectangle3 cir = new Rectangle3();
		cir.area();
		cir.display();
		cir.volume();
		

	}

}
