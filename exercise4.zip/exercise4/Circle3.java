package com.InheriandAbstract.exercise4;

public class Circle3 extends Shape3


{
	void area()
	{
		System.out.println("Display Circle");
	}
	

}
