package com.InheriandAbstract.exercise4;

public class AccInheritMain8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrivateA8 super1 = new PrivateB8();
	      System.out.println(super1.x);
	      super1.derive();


	}

}
