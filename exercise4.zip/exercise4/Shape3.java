package com.InheriandAbstract.exercise4;

public class Shape3
{
	public void display() {
	      System.out.println("Shape Here");
	   }

}
