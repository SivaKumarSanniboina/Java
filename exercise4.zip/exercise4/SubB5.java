package com.InheriandAbstract.exercise4;

public class SubB5 
{
	protected void calculate(int k)
	{
		
	}

}
