package com.InheriandAbstract.exercise4;

public class FooMain9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Foo9 foo = new Bar9();
		 foo.addFive();
		 System.out.println("Value: "+ foo.a);


	}

}
