package com.InheriandAbstract.exercise4;

public class PrivateA7 {
    private void derive(){
   }


}
class PrivateB7 extends PrivateA7
{
	public void derive()
	{
		
		
	}
	
}
