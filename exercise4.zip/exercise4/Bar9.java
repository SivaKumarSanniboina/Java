package com.InheriandAbstract.exercise4;

public class Bar9 extends Foo9
{
	public int a;
    public Bar9() { a = 8; }
    public void addFive() { this.a +=5; }


}
