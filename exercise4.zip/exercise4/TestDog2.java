package com.InheriandAbstract.exercise4;

public class TestDog2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Animal2 a = new Animal2(); 
	      Animal2 b = new Dog2();
	      a.move();
	      b.move();

	}

}
