package com.InheriandAbstract.exercise4;

public class PrivateB8  extends PrivateA8
{
    int x = 10;
    public void derive(){ 
      System.out.println("Sub method");   
    }


}
