package com.InheriandAbstract.exercise4;

public class PrivateA8 
{
    int x = 5;
    protected void derive(){
      System.out.println("Super method");
    }
}
