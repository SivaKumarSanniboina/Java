package com.InheriandAbstract.exercise4;

public class Rectangle3 extends Circle3 
{
	 public void volume() {
	      System.out.println("rectangle Volume here");
	   }

}
