package com.InheriandAbstract.exercise4;

public class Animal2 
{
	 public void move() {
	      System.out.println("Animals can move");
	   }

}
