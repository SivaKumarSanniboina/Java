package com.InheriandAbstract.exercise4;

public class Foo9 
{
    public int a;
    public Foo9() { a = 3; }
    public void addFive() { a += 5; }


}
