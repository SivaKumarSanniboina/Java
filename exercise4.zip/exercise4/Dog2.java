package com.InheriandAbstract.exercise4;

public class Dog2 extends Animal2
{
	public void move() {
	      System.out.println("Dogs can walk and run");
	   }

}
