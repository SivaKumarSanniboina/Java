package com.htc.unload.main;

import java.io.IOException;
import java.sql.SQLException;

import com.htc.unload.dao.EmployeeDAO;
import com.htc.unload.dao.EmployeeDAOImpl;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		EmployeeDAO dao = new EmployeeDAOImpl();
		
		dao.unloadData();
	}

}
