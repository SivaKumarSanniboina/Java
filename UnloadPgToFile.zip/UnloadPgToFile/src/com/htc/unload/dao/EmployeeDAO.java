package com.htc.unload.dao;

import java.sql.SQLException;
import java.util.List;

import com.htc.unload.entity.Employee;

public interface EmployeeDAO 
{
	public void unloadData()throws SQLException;
	public void writeToExcel(List<Employee> emp);

}
