package com.htc.unload.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.LogManager;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.htc.unload.dbconnector.DBConnection;
import com.htc.unload.entity.Employee;



public class EmployeeDAOImpl implements EmployeeDAO{
	
	public static Logger logger = Logger.getLogger(EmployeeDAOImpl.class);
		
	Connection con;
	List<Employee> emplist = new ArrayList<Employee>();
	
	public EmployeeDAOImpl() throws ClassNotFoundException, IOException, SQLException {
		con = DBConnection.getConnection();
		LogManager.getLogManager().readConfiguration(new FileInputStream("src\\db.properties"));
		logger.info("Database connection obtained");
	}
	@Override
	public void unloadData() throws SQLException {
		// TODO Auto-generated method stub
		Statement stmt = con.createStatement();
		String query = "select empid,empname,address,designation,salary from employee1";
		ResultSet rs = stmt.executeQuery(query);
		logger.info("data reterived from database");
		while(rs.next())
		{
			Employee emp = new Employee();
			emp.setEmpId(rs.getString(1));
			emp.setEmpName(rs.getString(2));
			emp.setAddress(rs.getString(3));
			emp.setDesignation(rs.getString(4));
			emp.setSalary(rs.getInt(5));
			emplist.add(emp);
			
		}
		logger.info("data is writing into excel");
		writeToExcel(emplist);
		
	}

	@Override
	public void writeToExcel(List<Employee> emplist) {
		// TODO Auto-generated method stub
		String fileName = "Employee.xlsx";

		Workbook workbook = null;
		if (fileName.endsWith("xlsx"))
			workbook = new HSSFWorkbook();

		else if (fileName.endsWith("xls"))
			workbook = new XSSFWorkbook();
		else
			try {
				throw new FileNotFoundException("Excepted file format xls or xlsx is not found");
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			}
		
		Sheet sheet= workbook.createSheet("Employee");
		
		Row row;
		int rowno=0;
		int cellno=0;
		
		row = sheet.createRow(rowno);
		Cell cell = row.createCell(cellno);
		
		cell = row.createCell(cellno);
		cell.setCellValue("Emp Id");
		cellno++;
		
		cell = row.createCell(cellno);
		cell.setCellValue("Emp Name");
		cellno++;
		
		cell = row.createCell(cellno);
		cell.setCellValue("Address");
		cellno++;
		
		cell = row.createCell(cellno);
		cell.setCellValue("Designation");
		cellno++;
		
		cell = row.createCell(cellno);
		cell.setCellValue("Salary");
		cellno++;
		
		rowno++;
		
		for(Employee emp:emplist)
		{
			row = sheet.createRow(rowno);
			
			cellno=0;
			
			String empid = emp.getEmpId();
			String empname = emp.getEmpName();
			String address = emp.getAddress();
			String designation = emp.getDesignation();
			int salary = emp.getSalary();
			
			if(designation.equals("admin"))
			{
			cell = row.createCell(cellno);
			cell.setCellValue(empid);
			cellno++;
			
			cell = row.createCell(cellno);
			cell.setCellValue(empname);
			cellno++;
			
			cell = row.createCell(cellno);
			cell.setCellValue(address);
			cellno++;
			
			cell = row.createCell(cellno);
			cell.setCellValue(designation);
			cellno++;
			
			cell = row.createCell(cellno);
			cell.setCellValue(salary);
					
			rowno++;
			}
			
			
			
		}
		
		
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(fileName));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			workbook.write(fos);
			logger.info("Excel Write Succeeded...");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("workbook not found");
		}
	}

}
