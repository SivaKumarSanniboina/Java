package com.htc.TableToFile.main;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import com.htc.TableToFile.dao.IEmployeeImpl;
import com.htc.TableToFile.dao.IEmployeeInterface;

public class MainClass {
	public static void main(String[] args) throws SecurityException, FileNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		
		IEmployeeImpl impl = new IEmployeeImpl();
		
		impl.readFileFromFile();
		
		System.out.println("UnLoad Operation Done!!");
		
		
	}
}
