package com.basic.exercise2;

abstract class Bank
{
	abstract int getRateOfIntrest();
	
	
}
