package com.basic.exercise2;

public class Batch{
	int batchCode;
	int startDate;
	int endDate;
	String Trainee;
	
	public Trainee getTrainee(int traineeId)
	{
		return null;
		
	}
	public Trainee getTrainee(String gender)
	{
		return null;
		
		
	}

}
