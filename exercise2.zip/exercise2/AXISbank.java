package com.basic.exercise2;

public class AXISbank extends Bank
{
	int getRateOfIntrest()
	{
		return 10;
	}

}
