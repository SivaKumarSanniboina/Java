package com.basic.exercise2;

public class BankMain {

	public static void main(String[] args) 
	{
		Bank b=new SBIbank();
		System.out.println("SBI Bank Rate of Intrest is:"+b.getRateOfIntrest());
		
		
		Bank b1=new HDFCbank();
		System.out.println("HDFC Bank Rate of Intrest is:"+b1.getRateOfIntrest());
		
		Bank b2=new AXISbank();
		System.out.println("AXIS Bank Rate of Intrest is:"+b2.getRateOfIntrest());
		
	}


}
