package com.basic.exercise2;

public class MainStudent {

	public static void main(String[] args) 
	{
		

		Student s=new Student();   
		
		//Default Constructor
		System.out.println(s.getRollId()+"," + s.getName()+"," + s.getBranch()+ ","+ s.getAddress());

		s.setRollId(1414);
		s.setName("Siva");
		s.setBranch("CSE");
		s.setAddress("TVP");		
		System.out.println(s.getRollId()+"," + s.getName()+"," + s.getBranch()+ ","+ s.getAddress());
		
		//Parameterized Constructor
		Student s1=new Student();
		
		s1.setRollId(2424);
		s1.setName("Ravi");
		s1.setBranch("EEE");
		s1.setAddress("TVP");
		
		System.out.println(s1.getRollId()+"," + s1.getName()+"," + s1.getBranch()+ ","+ s1.getAddress());

 
	}

}
