package com.basic.exercise2;

public class ProjectMain {
	public static void main(String []args)
	{
		Project p=new Project();
		//Default Constructor
		System.out.println(p.getProjectId()+","+p.getProjectName()+ ","+p.getProjectHead()+","+p.getNoOfResources());

		p.setProjectId(26222);
		p.setProjectName("Banking");
		p.setProjectHead("JOY");
		p.setNoOfResources(4);
		
		System.out.println(p.getProjectId()+","+p.getProjectName()+ ","+p.getProjectHead()+","+p.getNoOfResources());
		
		p.setProjectId(444);
		p.setProjectName("OLA");
		p.setProjectHead("Carry");
		p.setNoOfResources(10);
		
		System.out.println(p.getProjectId()+","+p.getProjectName()+ ","+p.getProjectHead()+","+p.getNoOfResources());
		
		//Parameterized Constructor
		Project p1=new Project();
		p1.setProjectId(1111);
		p1.setProjectName("Amazon");
		p1.setProjectHead("Jeff");
		p1.setNoOfResources(20);
		
		System.out.println(p1.getProjectId()+","+p1.getProjectName()+ ","+p1.getProjectHead()+","+p1.getNoOfResources());


	}

}
