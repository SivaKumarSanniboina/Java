package com.basic.exercise2;

class SBIbank extends Bank
{
	int getRateOfIntrest()
	{
		return 7 ;
	}


}
