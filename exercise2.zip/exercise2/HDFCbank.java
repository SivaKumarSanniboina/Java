package com.basic.exercise2;

class HDFCbank extends Bank 
{
	int getRateOfIntrest()
	{
		return 8;
	}

}
