package com.basic.exercise2;

public class Student {
	private int rollId;
	private String name;
	private String branch;
	private String address;
	
	//Default constructor
	public Student()
	{
		
	}
		
	//parameterized constructor
	public Student(int rollId, String name, String branch, String address) {
		super();
		this.rollId = rollId;
		this.name = name;
		this.branch = branch;
		this.address = address;
	}




	public int getRollId() {
		return rollId;
	}
	public void setRollId(int rollId) {
		this.rollId = rollId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

	
	
	

}
