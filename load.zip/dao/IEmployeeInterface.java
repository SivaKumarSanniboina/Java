package com.htc.TableToFile.dao;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;


import com.htc.TableToFile.entity.EmployeeList;
public interface IEmployeeInterface {
	public void readFileFromFile() throws IOException, SQLException;
	public boolean insertToTable(EmployeeList obj) throws SQLException, IOException;

}
