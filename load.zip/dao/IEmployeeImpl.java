package com.htc.TableToFile.dao;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import com.htc.TableToFile.dbconnection.DbConnector;
import com.htc.TableToFile.entity.EmployeeList;
import com.htc.TableToFile.main.MainClass;

public class IEmployeeImpl {
	public static Logger logger =Logger.getLogger(MainClass.class);
	public void readFileFromFile() throws IOException, SQLException {
		// TODO Auto-generated method stub
           
		File file = new File("src//EmployeeListDetails.xlsx");


		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0); 
		Iterator<Row> itr = sheet.iterator();

		Row row = itr.next();
		int insert_table_counter = 0;
		int read_file_counter = 0;
		while (itr.hasNext()) 
		{
			row = itr.next();
			Iterator<Cell> cellIterator = row.cellIterator(); 

			
			while (cellIterator.hasNext()) {
				
				Cell cell = cellIterator.next();
				int empId = (int)cell.getNumericCellValue();

				cell = cellIterator.next();
				String empName = cell.getStringCellValue();

				cell = cellIterator.next();
				double salary = cell.getNumericCellValue();
				
				cell = cellIterator.next();
				String emailid = cell.getStringCellValue();

				cell = cellIterator.next();
				String gender = cell.getStringCellValue();
				 
           	  EmployeeList obj = new EmployeeList(empId,empName,salary,emailid,gender);
           	  insertToTable(obj); 
           	  logger.info("inserted to table");
             
		           }
			 
		}
	}
	

	private boolean insertToTable(EmployeeList obj) throws SQLException, IOException{
		// TODO Auto-generated method stub
		
		
			// TODO Auto-generated method stub

			boolean status = false;

			Connection con = DbConnector.getConnection();
					
			PreparedStatement ps = con.prepareStatement(
					"INSERT INTO employeedetails(empId, empName, salary, emailid, gender) VALUES(?,?,?,?,?)");

			ps.setInt(1, obj.getEmpId());
			ps.setString(2, obj.getEmpName());
			ps.setDouble(3, obj.getSalary());
			ps.setString(4, obj.getEmailid());
			ps.setString(5, obj.getGender());
			status = !ps.execute(); 

			return status;
		
	}
}


	
		
	

	
